import Component from "../gaming-app-dark"

export default function Page() {
  return <Component />
}
