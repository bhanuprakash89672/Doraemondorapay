import { initializeApp } from "firebase/app"
import { getDatabase } from "firebase/database"

const firebaseConfig = {
  apiKey: "AIzaSyD9c-17CtfgyOVdjlNjWKcv97LzrxG7bRs",
  authDomain: "rxxx-f91f0.firebaseapp.com",
  databaseURL: "https://rxxx-f91f0-default-rtdb.firebaseio.com",
  projectId: "rxxx-f91f0",
  storageBucket: "rxxx-f91f0.firebasestorage.app",
  messagingSenderId: "200365870595",
  appId: "1:200365870595:android:6633f3dabc291af7be4836",
}

const app = initializeApp(firebaseConfig)
export const database = getDatabase(app)
