import { database } from "@/lib/firebase"
import { ref, get, set, onValue, update, type Unsubscribe } from "firebase/database"

/* ------------------------------------------------------------------------- */
/*                              Type Definitions                             */
/* ------------------------------------------------------------------------- */

export interface User {
  id: string
  createdAt: number
  isPremium: boolean
  premiumExpiry: number | null // UNIX ms – null means not premium
}

export interface GlobalPrediction {
  periodNumber: string
  color: string
  number: number
  bigSmall: string
  timestamp: number
}

export interface AppSettings {
  maintenanceMode: boolean
  logoUrl: string
  appName: string
}

/* ------------------------------------------------------------------------- */
/*                                UserService                                */
/* ------------------------------------------------------------------------- */

export class UserService {
  /* ------------------------------ Singleton ----------------------------- */
  private static instance: UserService
  static getInstance(): UserService {
    if (!UserService.instance) UserService.instance = new UserService()
    return UserService.instance
  }

  private constructor() {}

  /* ---------------------------- User Helpers ---------------------------- */

  /** Generate a unique user ID */
  private generateUserId(): string {
    return "user_" + Math.random().toString(36).substr(2, 9) + "_" + Date.now()
  }

  /**
   * Create / fetch a local userId and make sure the record exists in Firebase
   * – returns the _id_ string
   */
  async initializeUser(): Promise<string> {
    try {
      let uid = localStorage.getItem("gaming_user_id") ?? ""

      // If no saved id, create a fresh one making sure it is unique in DB
      if (!uid) {
        while (true) {
          uid = this.generateUserId()
          // Does user already exist?
          const snapshot = await get(ref(database, `users/${uid}`))
          if (!snapshot.exists()) break
        }

        const newUser: User = {
          id: uid,
          createdAt: Date.now(),
          isPremium: false,
          premiumExpiry: null,
        }

        await set(ref(database, `users/${uid}`), newUser)
        localStorage.setItem("gaming_user_id", uid)
      }

      return uid
    } catch (error) {
      console.error("Error initializing user:", error)
      throw new Error("Failed to initialize user: " + error.message)
    }
  }

  /** Fetch a user record – returns null when no user exists */
  async getUser(userId: string): Promise<User | null> {
    try {
      const snapshot = await get(ref(database, `users/${userId}`))
      if (!snapshot.exists()) return null

      const user: User = snapshot.val()

      /* If premium expired – downgrade & persist */
      if (user.isPremium && user.premiumExpiry && user.premiumExpiry < Date.now()) {
        user.isPremium = false
        user.premiumExpiry = null
        await set(ref(database, `users/${userId}`), user)
      }

      return user
    } catch (error) {
      console.error("Error getting user:", error)
      return null
    }
  }

  /** Listen for realtime user changes – returns unsubscribe fn */
  onUserChange(userId: string, cb: (u: User) => void): Unsubscribe {
    const userRef = ref(database, `users/${userId}`)
    return onValue(userRef, (snap) => {
      if (snap.exists()) cb(snap.val() as User)
    })
  }

  /* -------------------------- Premium Management ------------------------ */

  /**
   * Add N premium **days** to a user by user ID.
   */
  async addPremiumDaysByUserId(userId: string, days: number): Promise<void> {
    try {
      // Check if user exists, if not create them
      let user = await this.getUser(userId)
      if (!user) {
        const newUser: User = {
          id: userId,
          createdAt: Date.now(),
          isPremium: false,
          premiumExpiry: null,
        }
        await set(ref(database, `users/${userId}`), newUser)
        user = newUser
      }

      const base = user.premiumExpiry && user.premiumExpiry > Date.now() ? user.premiumExpiry : Date.now()
      const newExpiry = base + days * 24 * 60 * 60 * 1000

      await update(ref(database, `users/${userId}`), {
        isPremium: true,
        premiumExpiry: newExpiry,
      })

      console.log(`Added ${days} premium days to user ${userId}. New expiry: ${new Date(newExpiry)}`)
    } catch (error) {
      console.error("Error adding premium days:", error)
      throw new Error("Failed to add premium to user")
    }
  }

  /**
   * Remove premium access from a user
   */
  async removePremiumFromUser(userId: string): Promise<void> {
    try {
      const user = await this.getUser(userId)
      if (!user) throw new Error("User not found")

      await update(ref(database, `users/${userId}`), {
        isPremium: false,
        premiumExpiry: null,
      })
    } catch (error) {
      console.error("Error removing premium:", error)
      throw error
    }
  }

  /* -------------------------- Global Prediction ------------------------- */

  async setGlobalPrediction(p: GlobalPrediction): Promise<void> {
    try {
      await set(ref(database, "globalPrediction"), p)
    } catch (error) {
      console.error("Error setting global prediction:", error)
    }
  }

  onGlobalPredictionChange(cb: (p: GlobalPrediction | null) => void): Unsubscribe {
    return onValue(ref(database, "globalPrediction"), (snap) => {
      cb(snap.exists() ? (snap.val() as GlobalPrediction) : null)
    })
  }

  /* ------------------------------ App Settings -------------------------- */

  async getAppSettings(): Promise<AppSettings> {
    try {
      const snap = await get(ref(database, "appSettings"))
      if (snap.exists()) return snap.val() as AppSettings

      // If no settings yet – create defaults
      const defaultSettings: AppSettings = {
        maintenanceMode: false,
        logoUrl: "",
        appName: "ASHURA AI",
      }
      await set(ref(database, "appSettings"), defaultSettings)
      return defaultSettings
    } catch (error) {
      console.error("Error getting app settings:", error)
      return {
        maintenanceMode: false,
        logoUrl: "",
        appName: "ASHURA AI",
      }
    }
  }

  async updateAppSettings(settings: Partial<AppSettings>): Promise<void> {
    try {
      await update(ref(database, "appSettings"), settings)
    } catch (error) {
      console.error("Error updating app settings:", error)
      throw error
    }
  }

  onAppSettingsChange(cb: (s: AppSettings) => void): Unsubscribe {
    return onValue(ref(database, "appSettings"), (snap) => {
      if (snap.exists()) cb(snap.val() as AppSettings)
    })
  }

  /* ------------------------------ Admin Utils --------------------------- */

  /** Fetch all users – used by Admin panel */
  async getAllUsers(): Promise<User[]> {
    try {
      const snap = await get(ref(database, "users"))
      if (!snap.exists()) return []

      const users: User[] = []
      snap.forEach((childSnap) => {
        const userData = childSnap.val()
        users.push({
          id: childSnap.key as string,
          createdAt: userData.createdAt || Date.now(),
          isPremium: userData.isPremium || false,
          premiumExpiry: userData.premiumExpiry || null,
        })
      })

      // Sort by creation date (newest first)
      users.sort((a, b) => b.createdAt - a.createdAt)

      console.log("Loaded users from Firebase:", users)
      return users
    } catch (error) {
      console.error("Error getting all users:", error)
      return []
    }
  }
}

/* ------------------------------------------------------------------------- */
/*                        Convenience Singleton Export                       */
/* ------------------------------------------------------------------------- */

export const userService = UserService.getInstance()
