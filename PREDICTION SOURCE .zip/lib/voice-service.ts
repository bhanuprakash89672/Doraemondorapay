export class VoiceService {
  private static instance: VoiceService

  static getInstance(): VoiceService {
    if (!VoiceService.instance) {
      VoiceService.instance = new VoiceService()
    }
    return VoiceService.instance
  }

  private speak(message: string) {
    try {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        const utterance = new SpeechSynthesisUtterance(message)
        utterance.rate = 0.8
        utterance.pitch = 1
        utterance.volume = 0.7
        window.speechSynthesis.speak(utterance)
      }
    } catch (error) {
      console.warn("Voice not available:", error)
    }
  }

  speakResult(color: string, number: number, bigSmall: string) {
    const message = `Result is ${color} ${number} ${bigSmall}`
    this.speak(message)
  }

  speakPredictionMade(type: string, value: string | number) {
    const message = `Prediction made for ${type} ${value}`
    this.speak(message)
  }

  speakPremiumRequired() {
    this.speak("Premium subscription required to access this feature")
  }

  speakVipRequired() {
    this.speak("VIP license required to access prediction dashboard")
  }

  speakVipActivated() {
    this.speak("VIP license activated successfully")
  }

  speakInvalidVipKey() {
    this.speak("Invalid or already used VIP license key")
  }

  speakAdminAction(message: string) {
    this.speak(message)
  }

  speakDepositBalance() {
    this.speak("Contact admin to add balance to your account")
  }

  speakInsufficientBalance() {
    this.speak("Insufficient balance for this prediction")
  }
}
