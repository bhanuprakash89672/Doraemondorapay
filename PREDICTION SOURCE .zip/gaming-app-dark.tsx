"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Notification } from "@/components/ui/notification"
import {
  ChevronLeft,
  Headphones,
  Clock,
  Target,
  TrendingUp,
  Wrench,
  Shield,
  Star,
  Sparkles,
  Activity,
  BarChart3,
  Brain,
} from "lucide-react"
import { UserService, type GlobalPrediction, type User, type AppSettings } from "@/lib/user-service"
import { VoiceService } from "@/lib/voice-service"

async function fetchGameResult() {
  try {
    const response = await fetch("https://api.bdg88zf.com/api/webapi/GetNoaverageEmerdList", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        pageSize: 10,
        pageNo: 1,
        typeId: 1,
        language: 0,
        random: "4a0522c6ecd8410496260e686be2a57c",
        signature: "334B5E70A0C9B8918B0B15E517E2069C",
        timestamp: Math.floor(Date.now() / 1000),
      }),
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data?.data?.list?.[0] || generateMockData()
  } catch (error) {
    console.warn("API unavailable, using mock data:", error.message)
    return generateMockData()
  }
}

function generateMockData() {
  const currentTime = Date.now()
  const now = new Date()

  const year = now.getFullYear().toString().slice(-2)
  const month = String(now.getMonth() + 1).padStart(2, "0")
  const date = String(now.getDate()).padStart(2, "0")
  const hour = String(now.getHours()).padStart(2, "0")
  const minute = String(now.getMinutes()).padStart(2, "0")

  const seconds = String(Math.floor(now.getSeconds() / 10)).padStart(1, "0")
  const issueNumber = `${year}${month}${date}${hour}${minute}${seconds}`

  return {
    issueNumber: issueNumber,
    status: "active",
    gameType: "WinGo 1 Min",
    timestamp: currentTime,
  }
}

function generatePredictions() {
  const colors = ["green", "red", "violet"]
  const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
  const bigSmall = ["big", "small"]

  return {
    color: colors[Math.floor(Math.random() * colors.length)],
    number: numbers[Math.floor(Math.random() * numbers.length)],
    bigSmall: bigSmall[Math.floor(Math.random() * bigSmall.length)],
  }
}

function generateGameResult() {
  const colors = ["green", "red", "violet"]
  const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

  const resultNumber = numbers[Math.floor(Math.random() * numbers.length)]
  return {
    color: colors[Math.floor(Math.random() * colors.length)],
    number: resultNumber,
    bigSmall: resultNumber >= 5 ? "big" : "small",
  }
}

function getCurrentPeriodNumber() {
  const now = new Date()
  const utcNow = new Date(now.getTime() + now.getTimezoneOffset() * 60000)
  const minutes = utcNow.getMinutes()
  const totalMinutes = utcNow.getHours() * 60 + minutes
  const dateStr = utcNow.toISOString().slice(0, 10).replace(/-/g, "")
  return `${dateStr}1000${10001 + totalMinutes}`
}

export default function Component() {
  const [showThemeSelector, setShowThemeSelector] = useState(false)
  const [selectedTheme, setSelectedTheme] = useState("blue")

  // User Management
  const [userId, setUserId] = useState<string>("")
  const [user, setUser] = useState<User | null>(null)
  const [userUnsubscribe, setUserUnsubscribe] = useState<(() => void) | null>(null)

  // Notification System
  const [notification, setNotification] = useState<{
    type: "success" | "error" | "warning" | "info"
    title: string
    message: string
    isVisible: boolean
  }>({
    type: "info",
    title: "",
    message: "",
    isVisible: false,
  })

  // App Settings
  const [appSettings, setAppSettings] = useState<AppSettings>({
    maintenanceMode: false,
    logoUrl: "",
    appName: "ASHURA AI",
  })

  const themes = {
    blue: {
      primary: "from-blue-500 to-blue-600",
      secondary: "from-blue-400 to-blue-500",
      shadow: "rgba(59, 130, 246, 0.4)",
      border: "border-blue-500/30",
      glow: "rgba(59, 130, 246, 0.1)",
      text: "text-blue-100",
      shadowHex: "59, 130, 246",
      accent: "bg-blue-500/20",
    },
    red: {
      primary: "from-red-500 to-red-600",
      secondary: "from-red-400 to-red-500",
      shadow: "rgba(239, 68, 68, 0.4)",
      border: "border-red-500/30",
      glow: "rgba(239, 68, 68, 0.1)",
      text: "text-red-100",
      shadowHex: "239, 68, 68",
      accent: "bg-red-500/20",
    },
    purple: {
      primary: "from-purple-500 to-purple-600",
      secondary: "from-purple-400 to-purple-500",
      shadow: "rgba(147, 51, 234, 0.4)",
      border: "border-purple-500/30",
      glow: "rgba(147, 51, 234, 0.1)",
      text: "text-purple-100",
      shadowHex: "147, 51, 234",
      accent: "bg-purple-500/20",
    },
    golden: {
      primary: "from-yellow-500 to-yellow-600",
      secondary: "from-yellow-400 to-yellow-500",
      shadow: "rgba(234, 179, 8, 0.4)",
      border: "border-yellow-500/30",
      glow: "rgba(234, 179, 8, 0.1)",
      text: "text-yellow-100",
      shadowHex: "234, 179, 8",
      accent: "bg-yellow-500/20",
    },
    green: {
      primary: "from-emerald-500 to-emerald-600",
      secondary: "from-emerald-400 to-emerald-500",
      shadow: "rgba(16, 185, 129, 0.4)",
      border: "border-emerald-500/30",
      glow: "rgba(16, 185, 129, 0.1)",
      text: "text-emerald-100",
      shadowHex: "16, 185, 129",
      accent: "bg-emerald-500/20",
    },
    orange: {
      primary: "from-orange-500 to-orange-600",
      secondary: "from-orange-400 to-orange-500",
      shadow: "rgba(249, 115, 22, 0.4)",
      border: "border-orange-500/30",
      glow: "rgba(249, 115, 22, 0.1)",
      text: "text-orange-100",
      shadowHex: "249, 115, 22",
      accent: "bg-orange-500/20",
    },
  }

  const currentTheme = themes[selectedTheme]
  const [gameData, setGameData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("Chart")
  const [predictions, setPredictions] = useState<any>(null)
  const [currentPeriodNumber, setCurrentPeriodNumber] = useState(getCurrentPeriodNumber())
  const [predictionHistory, setPredictionHistory] = useState<
    Array<{
      periodNumber: string
      predictions: {
        color: string
        number: number
        bigSmall: string
      }
      result?: {
        color: string
        number: number
        bigSmall: string
      }
    }>
  >([])

  const userService = UserService.getInstance()
  const voiceService = VoiceService.getInstance()

  // Notification helper
  const showNotification = (type: "success" | "error" | "warning" | "info", title: string, message: string) => {
    setNotification({
      type,
      title,
      message,
      isVisible: true,
    })
  }

  const hideNotification = () => {
    setNotification((prev) => ({ ...prev, isVisible: false }))
  }

  // Initialize user and setup listeners
  useEffect(() => {
    const initUser = async () => {
      try {
        const newUserId = await userService.initializeUser()
        setUserId(newUserId)

        const userData = await userService.getUser(newUserId)
        setUser(userData)

        // Listen for user changes
        const unsubscribe = userService.onUserChange(newUserId, (userData) => {
          setUser(userData)
        })
        setUserUnsubscribe(() => unsubscribe)

        // Listen for app settings changes
        userService.onAppSettingsChange((settings) => {
          setAppSettings(settings)
        })

        // Listen for global prediction changes (only for premium users)
        userService.onGlobalPredictionChange((globalPrediction) => {
          if (
            globalPrediction &&
            userData?.isPremium &&
            userData?.premiumExpiry &&
            userData.premiumExpiry > Date.now()
          ) {
            setPredictions({
              color: globalPrediction.color,
              number: globalPrediction.number,
              bigSmall: globalPrediction.bigSmall,
            })
          }
        })
      } catch (error) {
        console.error("Error initializing user:", error)
        showNotification("error", "Initialization Error", "Failed to initialize user session. Please refresh the page.")
      }
    }

    initUser()

    return () => {
      if (userUnsubscribe) {
        userUnsubscribe()
      }
    }
  }, [])

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const result = await fetchGameResult()
        setGameData(result)
      } catch (error) {
        console.warn("Failed to fetch game data:", error)
        setGameData(generateMockData())
      } finally {
        setLoading(false)
      }
    }

    fetchData()
    const interval = setInterval(fetchData, 30000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const timer = setInterval(async () => {
      const newPeriodNumber = getCurrentPeriodNumber()

      if (newPeriodNumber !== currentPeriodNumber) {
        // Generate result for the completed period
        const gameResult = generateGameResult()

        // Announce the result via voice only if user is premium
        if (user?.isPremium && user?.premiumExpiry && user.premiumExpiry > Date.now()) {
          voiceService.speakResult(gameResult.color, gameResult.number, gameResult.bigSmall)
        }

        // Only update prediction history if user is premium
        if (user?.isPremium && user?.premiumExpiry && user.premiumExpiry > Date.now() && predictions) {
          setPredictionHistory((prev) => {
            const newHistory = [
              {
                periodNumber: currentPeriodNumber,
                predictions: { ...predictions },
                result: gameResult,
              },
              ...prev,
            ].slice(0, 10)
            return newHistory
          })
        }

        setCurrentPeriodNumber(newPeriodNumber)

        // Generate new predictions and save to Firebase (same for all users)
        const newPredictions = generatePredictions()

        // Only set predictions if user is premium
        if (user?.isPremium && user?.premiumExpiry && user.premiumExpiry > Date.now()) {
          setPredictions(newPredictions)
        }

        const globalPrediction: GlobalPrediction = {
          periodNumber: newPeriodNumber,
          color: newPredictions.color,
          number: newPredictions.number,
          bigSmall: newPredictions.bigSmall,
          timestamp: Date.now(),
        }

        await userService.setGlobalPrediction(globalPrediction)
      }
    }, 1000)

    return () => clearInterval(timer)
  }, [currentPeriodNumber, predictions, user?.isPremium, user?.premiumExpiry])

  const hasValidPremium = user?.isPremium && user?.premiumExpiry && user.premiumExpiry > Date.now()

  const isPredictedColor = (color: string) => {
    return hasValidPremium && predictions && predictions.color === color
  }

  const isPredictedNumber = (num: number) => {
    return hasValidPremium && predictions && predictions.number === num
  }

  const isPredictedBigSmall = (option: string) => {
    return hasValidPremium && predictions && predictions.bigSmall === option
  }

  const getColorDisplay = (color: string) => {
    const colorMap = {
      green: { bg: "bg-emerald-500", text: "G", name: "Green" },
      red: { bg: "bg-red-500", text: "R", name: "Red" },
      violet: { bg: "bg-purple-500", text: "V", name: "Violet" },
    }
    return colorMap[color] || { bg: "bg-gray-500", text: "?", name: "Unknown" }
  }

  const formatRemainingTime = (timestamp: number) => {
    const remaining = timestamp - Date.now()
    if (remaining <= 0) return "Expired"

    const days = Math.floor(remaining / (24 * 60 * 60 * 1000))
    const hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000))

    if (days > 0) return `${days}d ${hours}h`
    if (hours > 0) return `${hours}h`
    return "< 1h"
  }

  const calculateAccuracy = () => {
    if (predictionHistory.length === 0) return 0
    const correctPredictions = predictionHistory.filter(
      (history) =>
        history.result &&
        (history.predictions.color === history.result.color ||
          history.predictions.number === history.result.number ||
          history.predictions.bigSmall === history.result.bigSmall),
    ).length
    return Math.round((correctPredictions / predictionHistory.length) * 100)
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white relative">
      {/* Notification */}
      <Notification
        type={notification.type}
        title={notification.title}
        message={notification.message}
        isVisible={notification.isVisible}
        onClose={hideNotification}
      />

      {/* Maintenance Mode Overlay */}
      {appSettings.maintenanceMode && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <Card className="bg-gradient-to-br from-orange-600/90 to-red-700/90 border border-orange-500/50 max-w-md mx-4">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center">
                <Wrench className="h-8 w-8 text-white animate-pulse" />
              </div>
              <h2 className="text-xl font-bold text-white mb-2">Under Maintenance</h2>
              <p className="text-orange-100 text-sm mb-4">
                We're currently updating our system to serve you better. Please check back soon!
              </p>
              <div className="flex items-center justify-center gap-2 text-orange-200">
                <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></div>
                <div
                  className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"
                  style={{ animationDelay: "0.2s" }}
                ></div>
                <div
                  className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"
                  style={{ animationDelay: "0.4s" }}
                ></div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Enhanced Header */}
      <div className="bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 p-3 flex items-center justify-between border-b border-gray-700/50">
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:bg-gray-600 h-10 w-10 rounded-full"
          disabled={appSettings.maintenanceMode}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center border-2 border-white/20 overflow-hidden shadow-lg">
            {appSettings.logoUrl ? (
              <img
                src={appSettings.logoUrl || "/placeholder.svg"}
                alt="Logo"
                className="w-full h-full object-cover rounded-full"
                onError={(e) => {
                  e.currentTarget.style.display = "none"
                  e.currentTarget.nextElementSibling.style.display = "flex"
                }}
              />
            ) : null}
            <span className={`text-white font-bold text-sm ${appSettings.logoUrl ? "hidden" : ""}`}>⚡</span>
          </div>
          <div className="text-center">
            <span className="text-white font-bold text-lg">{appSettings.appName}</span>
            <div className="text-xs text-gray-400">AI Predictions</div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-gray-600 h-10 w-10 rounded-full"
            disabled={appSettings.maintenanceMode}
          >
            <Headphones className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-gray-600 h-10 w-10 rounded-full"
            disabled={appSettings.maintenanceMode}
          >
            <Clock className="h-5 w-5" />
          </Button>
        </div>
      </div>

      <div className="p-3 space-y-3">
        {/* Enhanced User Status Card */}
        <Card
          className={`bg-gradient-to-br from-black/90 to-gray-900/90 border ${hasValidPremium ? "border-green-500/50" : "border-gray-500/50"} shadow-2xl relative overflow-hidden`}
        >
          <div
            className={`absolute inset-0 bg-gradient-to-r ${hasValidPremium ? "from-green-500/10 via-transparent to-blue-500/10" : "from-gray-500/10 via-transparent to-gray-600/10"}`}
          ></div>
          <div
            className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${hasValidPremium ? "from-green-500 via-blue-500 to-purple-500" : "from-gray-500 via-gray-600 to-gray-500"}`}
          ></div>
          <CardContent className="p-4 relative z-10">
            <div className="text-center space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-center gap-3">
                  <div
                    className={`w-8 h-8 bg-gradient-to-br ${hasValidPremium ? "from-green-400 to-blue-500" : "from-gray-500 to-gray-600"} rounded-full flex items-center justify-center`}
                  >
                    <Shield className="h-5 w-5 text-white" />
                  </div>
                  <span className="font-bold text-lg text-white">
                    {hasValidPremium ? "PREMIUM ACTIVE" : "REGULAR USER"}
                  </span>
                  <div
                    className={`w-2 h-2 ${hasValidPremium ? "bg-green-400" : "bg-gray-400"} rounded-full animate-pulse`}
                  ></div>
                </div>

                <div className="text-xs text-gray-400 font-mono bg-gray-800/50 px-3 py-1 rounded-full inline-block">
                  ID: {userId}
                </div>
                {hasValidPremium && (
                  <div className="text-sm text-green-300 bg-green-500/10 px-3 py-1 rounded-full border border-green-500/20">
                    Premium Expires: {user?.premiumExpiry ? formatRemainingTime(user.premiumExpiry) : "Never"}
                  </div>
                )}
              </div>

              <div className="flex gap-3 justify-center">
                <Button
                  onClick={() => setShowThemeSelector(!showThemeSelector)}
                  disabled={appSettings.maintenanceMode}
                  className={`flex-1 px-6 py-2 bg-gradient-to-r ${currentTheme.primary} hover:scale-105 text-white font-bold rounded-full shadow-lg transition-all duration-300 text-sm`}
                  style={{
                    boxShadow: `0 0 15px ${currentTheme.shadow}`,
                  }}
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Theme
                </Button>
              </div>

              {/* Enhanced Theme Selector */}
              {showThemeSelector && (
                <div className="mt-3 p-3 bg-gradient-to-br from-slate-800/90 to-slate-900/90 rounded-xl border border-white/20 backdrop-blur-md shadow-2xl">
                  <div className="text-center mb-3">
                    <span className="text-white text-sm font-medium flex items-center justify-center gap-2">
                      <Sparkles className="h-4 w-4 text-yellow-400" />
                      Select Theme
                      <Sparkles className="h-4 w-4 text-yellow-400" />
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {Object.entries(themes).map(([themeKey, theme]) => (
                      <Button
                        key={themeKey}
                        onClick={() => {
                          setSelectedTheme(themeKey)
                          setShowThemeSelector(false)
                        }}
                        disabled={appSettings.maintenanceMode}
                        className={`p-3 bg-gradient-to-r ${theme.primary} hover:scale-105 text-white font-bold rounded-xl shadow-lg transition-all duration-300 text-xs capitalize relative overflow-hidden ${
                          selectedTheme === themeKey ? "ring-2 ring-white scale-105" : ""
                        }`}
                        style={{
                          boxShadow: `0 0 12px ${theme.shadow}`,
                        }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                        <span className="relative z-10">{themeKey}</span>
                        {selectedTheme === themeKey && (
                          <div className="absolute top-1 right-1">
                            <Star className="h-3 w-3 text-yellow-300" />
                          </div>
                        )}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Enhanced AI Status Notification */}
        <Card className="bg-gradient-to-r from-gray-800/90 to-gray-700/90 border border-gray-600/50 backdrop-blur-sm">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                  <Brain className="h-4 w-4 text-white" />
                </div>
                <div>
                  <span className="text-sm font-medium text-white">AI Prediction Engine</span>
                  <div
                    className={`text-xs ${hasValidPremium ? "text-green-400" : "text-gray-400"} flex items-center gap-1`}
                  >
                    <div
                      className={`w-1 h-1 ${hasValidPremium ? "bg-green-400" : "bg-gray-400"} rounded-full animate-pulse`}
                    ></div>
                    {hasValidPremium ? "Premium Active" : "Premium Required"}
                  </div>
                </div>
              </div>
              <Button
                size="sm"
                disabled={appSettings.maintenanceMode}
                className={`bg-gradient-to-r ${currentTheme.primary} hover:scale-105 text-white px-3 py-1 rounded-full text-xs shadow-lg`}
                style={{
                  boxShadow: `0 0 10px ${currentTheme.shadow}`,
                }}
              >
                <Target className="h-3 w-3 mr-1" />
                Details
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Game Selection */}
        <Card className="bg-gradient-to-br from-gray-800/90 to-gray-700/90 border border-gray-600/50">
          <CardContent className="p-3">
            <div className="grid grid-cols-4 gap-2">
              {[
                { name: "WinGo", time: "30sec", active: false },
                { name: "WinGo 1", time: "Min", active: true },
                { name: "WinGo 3", time: "Min", active: false },
                { name: "WinGo 5", time: "Min", active: false },
              ].map((game, index) => (
                <div
                  key={index}
                  className={`text-center p-3 rounded-xl transition-all duration-300 relative overflow-hidden ${
                    game.active && !appSettings.maintenanceMode
                      ? `bg-gradient-to-br ${currentTheme.primary} shadow-lg`
                      : "bg-gray-700/50 hover:bg-gray-600/50"
                  } ${appSettings.maintenanceMode ? "opacity-50" : ""}`}
                  style={
                    game.active && !appSettings.maintenanceMode
                      ? {
                          boxShadow: `0 0 15px ${currentTheme.shadow}`,
                        }
                      : {}
                  }
                >
                  {game.active && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                  )}
                  <div className="relative z-10">
                    <div className="w-6 h-6 bg-gray-600/50 rounded-full mx-auto mb-2 flex items-center justify-center">
                      <Clock className="h-3 w-3 text-gray-300" />
                    </div>
                    <div className="text-xs font-medium text-white">{game.name}</div>
                    <div className="text-xs text-gray-300">{game.time}</div>
                    {game.active && (
                      <div className="absolute top-1 right-1">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Active Game Card */}
        <Card
          className={`relative bg-gradient-to-br from-slate-800/95 to-slate-900/95 ${currentTheme.border} backdrop-blur-md overflow-hidden shadow-2xl`}
        >
          <div
            className="absolute inset-0 bg-gradient-to-br via-transparent"
            style={{
              background: `linear-gradient(to bottom right, ${currentTheme.glow} 15%, transparent 50%, ${currentTheme.glow} 85%)`,
            }}
          ></div>

          <div
            className="absolute inset-0 rounded-lg opacity-60"
            style={{
              background: `linear-gradient(45deg, transparent 30%, ${currentTheme.glow} 50%, transparent 70%)`,
              animation: "borderGlow 3s ease-in-out infinite",
            }}
          ></div>

          <div
            className="absolute inset-0 rounded-lg"
            style={{
              boxShadow: `inset 0 1px 0 rgba(255, 255, 255, 0.1), inset 0 0 15px ${currentTheme.glow}, 0 6px 20px ${currentTheme.glow}`,
            }}
          ></div>

          <CardContent className="relative z-10 p-4">
            <div className="flex justify-between items-start mb-3">
              <div className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={appSettings.maintenanceMode}
                  className={`${currentTheme.border} ${currentTheme.text} hover:bg-opacity-20 hover:text-white backdrop-blur-sm transition-all duration-300 font-medium text-xs px-3 py-2`}
                  style={{
                    backgroundColor: `rgba(${currentTheme.shadowHex}, 0.15)`,
                    boxShadow: `0 3px 6px ${currentTheme.glow}, inset 0 1px 0 rgba(255, 255, 255, 0.1)`,
                  }}
                >
                  <span className="mr-2">📖</span>
                  How to play
                </Button>
                <div className="text-lg font-bold text-white drop-shadow-sm tracking-wide flex items-center gap-2">
                  WinGo 1 Min
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                </div>
              </div>
            </div>

            {/* Enhanced Period Number Section */}
            <div className="text-center space-y-3">
              <div className="space-y-2">
                <div
                  className={`text-sm font-medium ${currentTheme.text.replace("-100", "-60")} tracking-wide uppercase flex items-center justify-center gap-2`}
                >
                  <Activity className="h-4 w-4" />
                  Period Number
                </div>
                <div
                  className={`inline-flex items-center px-4 py-3 bg-gradient-to-r from-slate-700/90 to-slate-800/90 rounded-xl backdrop-blur-sm ${currentTheme.border} relative overflow-hidden shadow-lg`}
                >
                  <div
                    className="absolute inset-0 rounded-xl opacity-50"
                    style={{
                      background: `linear-gradient(45deg, transparent 30%, ${currentTheme.glow} 50%, transparent 70%)`,
                      animation: "borderGlow 4s ease-in-out infinite",
                    }}
                  ></div>

                  <span
                    className={`relative z-10 text-lg font-mono ${currentTheme.text} tracking-wider font-bold`}
                    style={{
                      textShadow: `0 0 8px ${currentTheme.shadow}, 0 0 16px ${currentTheme.shadow}`,
                    }}
                  >
                    {currentPeriodNumber}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <div
                  className={`text-sm font-medium ${currentTheme.text.replace("-100", "-60")} tracking-wide uppercase flex items-center justify-center gap-2`}
                >
                  <Brain className="h-4 w-4" />
                  AI Prediction Status
                </div>
                <div
                  className={`inline-flex items-center px-3 py-2 rounded-full backdrop-blur-sm border ${
                    hasValidPremium ? "bg-emerald-500/20 border-emerald-500/30" : "bg-gray-500/20 border-gray-500/30"
                  } shadow-lg`}
                >
                  <div
                    className={`w-2 h-2 rounded-full mr-2 animate-pulse ${hasValidPremium ? "bg-emerald-400" : "bg-gray-400"}`}
                  ></div>
                  <span className={`text-sm font-medium ${hasValidPremium ? "text-emerald-100" : "text-gray-300"}`}>
                    {hasValidPremium ? "Premium Active" : "Premium Required"}
                  </span>
                  {hasValidPremium && <Sparkles className="h-3 w-3 ml-2 text-yellow-400" />}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Color Betting */}
        <div className="grid grid-cols-3 gap-3">
          {[
            {
              name: "Green",
              color: "from-emerald-500 to-emerald-600",
              shadowColor: "rgba(16, 185, 129, 0.5)",
              value: "green",
            },
            {
              name: "Violet",
              color: "from-purple-500 to-purple-600",
              shadowColor: "rgba(147, 51, 234, 0.5)",
              value: "violet",
            },
            {
              name: "Red",
              color: "from-red-500 to-red-600",
              shadowColor: "rgba(239, 68, 68, 0.5)",
              value: "red",
            },
          ].map((option) => {
            const isPredicted = isPredictedColor(option.value)
            return (
              <Button
                key={option.value}
                onClick={() => {
                  if (!appSettings.maintenanceMode) {
                    voiceService.speakPredictionMade("color", option.value)
                  }
                }}
                disabled={appSettings.maintenanceMode}
                className={`bg-gradient-to-br ${option.color} hover:scale-105 text-white font-bold py-3 rounded-xl transition-all duration-300 text-sm relative overflow-hidden shadow-lg ${
                  isPredicted ? "animate-pulse ring-2 ring-white/50" : ""
                } ${appSettings.maintenanceMode ? "opacity-50 cursor-not-allowed" : ""}`}
                style={{
                  boxShadow: isPredicted
                    ? `0 0 20px ${option.shadowColor}, 0 0 40px ${option.shadowColor.replace("0.5", "0.3")}`
                    : `0 0 12px ${option.shadowColor.replace("0.5", "0.4")}, 0 3px 8px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)`,
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                <span className="relative z-10 drop-shadow-sm flex items-center justify-center gap-2">
                  {option.name}
                  {isPredicted && <Star className="h-4 w-4 text-yellow-300" />}
                </span>
              </Button>
            )
          })}
        </div>

        {/* Enhanced Number Grid */}
        <div className="flex justify-center">
          <div className="grid grid-cols-5 gap-2 w-fit">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((num, index) => {
              const isP = isPredictedNumber(num)
              return (
                <Button
                  key={num}
                  onClick={() => {
                    if (!appSettings.maintenanceMode) {
                      voiceService.speakPredictionMade("number", num.toString())
                    }
                  }}
                  disabled={appSettings.maintenanceMode}
                  className={`w-14 h-14 bg-gradient-to-br from-slate-700 to-slate-800 hover:from-slate-600 hover:to-slate-700 hover:scale-105 text-white font-bold rounded-xl transition-all duration-300 text-lg relative overflow-hidden shadow-lg ${
                    isP ? "animate-pulse ring-2 ring-white/50" : ""
                  } ${appSettings.maintenanceMode ? "opacity-50 cursor-not-allowed" : ""}`}
                  style={{
                    boxShadow: isP
                      ? `0 0 20px ${currentTheme.shadow}, 0 0 40px ${currentTheme.shadow.replace("0.4", "0.2")}`
                      : "0 3px 8px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)",
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                  <span className="relative z-10 drop-shadow-sm">{num}</span>
                  {isP && (
                    <div className="absolute top-1 right-1">
                      <Star className="h-3 w-3 text-yellow-300" />
                    </div>
                  )}
                </Button>
              )
            })}
          </div>
        </div>

        {/* Enhanced Big/Small */}
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: "Big", value: "big" },
            { name: "Small", value: "small" },
          ].map((option) => {
            const isPredicted = isPredictedBigSmall(option.value)
            return (
              <Button
                key={option.value}
                onClick={() => {
                  if (!appSettings.maintenanceMode) {
                    voiceService.speakPredictionMade("bigSmall", option.value)
                  }
                }}
                disabled={appSettings.maintenanceMode}
                className={`bg-gradient-to-br from-slate-700 to-slate-800 hover:from-slate-600 hover:to-slate-700 hover:scale-105 text-white font-bold py-3 rounded-xl transition-all duration-300 text-sm relative overflow-hidden shadow-lg ${
                  isPredicted ? "animate-pulse ring-2 ring-white/50" : ""
                } ${appSettings.maintenanceMode ? "opacity-50 cursor-not-allowed" : ""}`}
                style={{
                  boxShadow: isPredicted
                    ? `0 0 20px ${currentTheme.shadow}, 0 0 40px ${currentTheme.shadow.replace("0.4", "0.2")}`
                    : "0 3px 8px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)",
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                <span className="relative z-10 drop-shadow-sm flex items-center justify-center gap-2">
                  {option.name}
                  {isPredicted && <Star className="h-4 w-4 text-yellow-300" />}
                </span>
              </Button>
            )
          })}
        </div>

        {/* Enhanced Tabs */}
        <div className="flex bg-gradient-to-r from-gray-800 to-gray-700 rounded-xl p-1 shadow-lg border border-gray-600/50">
          {["Chart", "My history"].map((tab) => (
            <Button
              key={tab}
              onClick={() => setActiveTab(tab)}
              disabled={appSettings.maintenanceMode}
              className={`flex-1 text-sm py-3 rounded-lg transition-all duration-300 relative overflow-hidden ${
                activeTab === tab
                  ? `bg-gradient-to-r ${currentTheme.primary} text-white shadow-lg`
                  : "text-gray-400 hover:text-white hover:bg-gray-700/50"
              } ${appSettings.maintenanceMode ? "opacity-50 cursor-not-allowed" : ""}`}
              style={
                activeTab === tab
                  ? {
                      boxShadow: `0 0 15px ${currentTheme.shadow}`,
                    }
                  : {}
              }
            >
              <div className="flex items-center gap-2">
                {tab === "Chart" ? <BarChart3 className="h-4 w-4" /> : <Activity className="h-4 w-4" />}
                {tab}
              </div>
              {activeTab === tab && (
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-pulse"></div>
              )}
            </Button>
          ))}
        </div>

        {/* Enhanced Tab Content */}
        <Card className="bg-gradient-to-br from-gray-800/90 to-gray-700/90 border border-gray-600/50 shadow-lg">
          <CardContent className="p-4">
            {activeTab === "Chart" && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-3">
                  <BarChart3 className="h-5 w-5 text-blue-400" />
                  <span className="text-lg font-medium text-white">Trend Analysis</span>
                </div>
                <div className="text-center py-12 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-xl border border-blue-500/20">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="h-8 w-8 text-white" />
                  </div>
                  <div className="text-sm text-gray-300 mb-2">Advanced Chart Visualization</div>
                  <div className="text-xs text-gray-400">Coming soon with real-time analytics</div>
                  <div className="flex items-center justify-center gap-2 mt-3">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse delay-200"></div>
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-400"></div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "My history" && (
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-green-400" />
                    <span className="text-lg font-medium text-white">AI Predictions</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Target className="h-4 w-4 text-green-400" />
                    <span className="text-green-400 font-medium">Accuracy: {calculateAccuracy()}%</span>
                  </div>
                </div>
                {predictionHistory.length === 0 ? (
                  <div className="text-center py-12 bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-xl border border-gray-600/50">
                    <div className="w-16 h-16 bg-gradient-to-br from-gray-600 to-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Activity className="h-8 w-8 text-gray-400" />
                    </div>
                    <div className="text-sm text-gray-300 mb-2">No prediction history yet</div>
                    <div className="text-xs text-gray-400">
                      {hasValidPremium ? "Start playing to see AI predictions" : "Premium required for AI predictions"}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {predictionHistory.map((history, index) => {
                      const predColor = getColorDisplay(history.predictions.color)
                      const resultColor = history.result ? getColorDisplay(history.result.color) : null
                      const isCorrect =
                        history.result &&
                        (history.predictions.color === history.result.color ||
                          history.predictions.number === history.result.number ||
                          history.predictions.bigSmall === history.result.bigSmall)

                      return (
                        <div
                          key={index}
                          className="p-3 bg-gradient-to-r from-gray-700/80 to-gray-600/80 rounded-xl border border-gray-600/50 shadow-lg"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="text-xs text-gray-400 font-mono">Period: {history.periodNumber}</div>
                            {isCorrect && (
                              <div className="flex items-center gap-1 text-xs text-green-400 font-medium bg-green-500/20 px-2 py-1 rounded-full">
                                <Star className="h-3 w-3" />
                                Correct
                              </div>
                            )}
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="text-xs text-gray-300">Predicted:</div>
                              <div className={`w-5 h-5 ${predColor.bg} rounded-full shadow-lg`}></div>
                              <span className="text-white text-sm font-bold">{history.predictions.number}</span>
                              <span className="text-xs text-gray-400 capitalize bg-gray-600/50 px-2 py-1 rounded-full">
                                {history.predictions.bigSmall}
                              </span>
                            </div>
                            {history.result && (
                              <div className="flex items-center gap-3">
                                <div className="text-xs text-gray-300">Result:</div>
                                <div className={`w-5 h-5 ${resultColor.bg} rounded-full shadow-lg`}></div>
                                <span className="text-white text-sm font-bold">{history.result.number}</span>
                                <span className="text-xs text-gray-400 capitalize bg-gray-600/50 px-2 py-1 rounded-full">
                                  {history.result.bigSmall}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <style jsx>{`
        @keyframes borderGlow {
          0%,
          100% {
            opacity: 0.6;
          }
          50% {
            opacity: 1;
          }
        }
      `}</style>
    </div>
  )
}
