"use client"

import * as React from "react"
import { X, CheckCircle, AlertTriangle, Info, XCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface NotificationProps {
  type: "success" | "error" | "warning" | "info"
  title: string
  message: string
  isVisible: boolean
  onClose: () => void
  duration?: number
}

export function Notification({ type, title, message, isVisible, onClose, duration = 5000 }: NotificationProps) {
  React.useEffect(() => {
    if (isVisible && duration > 0) {
      const timer = setTimeout(() => {
        onClose()
      }, duration)
      return () => clearTimeout(timer)
    }
  }, [isVisible, duration, onClose])

  const icons = {
    success: CheckCircle,
    error: XCircle,
    warning: AlertTriangle,
    info: Info,
  }

  const colors = {
    success: {
      bg: "bg-gradient-to-r from-green-500/90 to-emerald-600/90",
      border: "border-green-400/30",
      icon: "text-green-100",
      text: "text-green-50",
    },
    error: {
      bg: "bg-gradient-to-r from-red-500/90 to-red-600/90",
      border: "border-red-400/30",
      icon: "text-red-100",
      text: "text-red-50",
    },
    warning: {
      bg: "bg-gradient-to-r from-orange-500/90 to-yellow-600/90",
      border: "border-orange-400/30",
      icon: "text-orange-100",
      text: "text-orange-50",
    },
    info: {
      bg: "bg-gradient-to-r from-blue-500/90 to-blue-600/90",
      border: "border-blue-400/30",
      icon: "text-blue-100",
      text: "text-blue-50",
    },
  }

  const Icon = icons[type]
  const colorScheme = colors[type]

  return (
    <div
      className={cn(
        "fixed top-4 left-1/2 transform -translate-x-1/2 z-50 transition-all duration-500 max-w-md w-full mx-4",
        isVisible ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0",
      )}
    >
      <div
        className={cn(
          "backdrop-blur-xl rounded-lg shadow-2xl border relative overflow-hidden",
          colorScheme.bg,
          colorScheme.border,
        )}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-white/5 via-transparent to-white/5"></div>
        <div className="relative p-4">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <Icon className={cn("h-5 w-5", colorScheme.icon)} />
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <h3 className={cn("font-semibold text-sm mb-1", colorScheme.text)}>{title}</h3>
              <p className={cn("text-xs leading-relaxed", colorScheme.text, "opacity-90")}>{message}</p>
            </div>
            <button
              onClick={onClose}
              className={cn(
                "flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center transition-colors",
                "hover:bg-white/20",
                colorScheme.icon,
              )}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
