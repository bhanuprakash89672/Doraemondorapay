"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ConfirmationDialog } from "@/components/ui/confirmation-dialog"
import { Notification } from "@/components/ui/notification"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Users,
  Settings,
  Copy,
  Calendar,
  Activity,
  CheckCircle,
  XCircle,
  Wrench,
  ImageIcon,
  Type,
  Shield,
  ShieldCheck,
  Plus,
  Trash2,
  Star,
  Edit,
  Save,
  RefreshCw,
} from "lucide-react"
import { UserService, type User, type AppSettings } from "@/lib/user-service"

export default function AdminPanel() {
  const [users, setUsers] = useState<User[]>([])
  const [appSettings, setAppSettings] = useState<AppSettings>({
    maintenanceMode: false,
    logoUrl: "",
    appName: "ASHURA AI",
  })
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [activeTab, setActiveTab] = useState("users")

  // Premium Management
  const [selectedUserId, setSelectedUserId] = useState("")
  const [premiumDays, setPremiumDays] = useState("30")
  const [managingPremium, setManagingPremium] = useState(false)

  // Edit Premium Dialog
  const [editDialog, setEditDialog] = useState<{
    isOpen: boolean
    user: User | null
    newDays: string
    isLoading: boolean
  }>({
    isOpen: false,
    user: null,
    newDays: "30",
    isLoading: false,
  })

  // Confirmation Dialog
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean
    title: string
    message: string
    type: "danger" | "warning" | "info" | "success"
    onConfirm: () => void
    isLoading: boolean
  }>({
    isOpen: false,
    title: "",
    message: "",
    type: "info",
    onConfirm: () => {},
    isLoading: false,
  })

  // Notification
  const [notification, setNotification] = useState<{
    type: "success" | "error" | "warning" | "info"
    title: string
    message: string
    isVisible: boolean
  }>({
    type: "info",
    title: "",
    message: "",
    isVisible: false,
  })

  const userService = UserService.getInstance()

  const showNotification = (type: "success" | "error" | "warning" | "info", title: string, message: string) => {
    setNotification({
      type,
      title,
      message,
      isVisible: true,
    })
  }

  const hideNotification = () => {
    setNotification((prev) => ({ ...prev, isVisible: false }))
  }

  const showConfirmDialog = (
    title: string,
    message: string,
    type: "danger" | "warning" | "info" | "success",
    onConfirm: () => void,
  ) => {
    setConfirmDialog({
      isOpen: true,
      title,
      message,
      type,
      onConfirm,
      isLoading: false,
    })
  }

  const closeConfirmDialog = () => {
    setConfirmDialog((prev) => ({ ...prev, isOpen: false }))
  }

  const executeConfirmAction = async () => {
    setConfirmDialog((prev) => ({ ...prev, isLoading: true }))
    try {
      await confirmDialog.onConfirm()
      closeConfirmDialog()
    } catch (error) {
      console.error("Error executing confirm action:", error)
      showNotification("error", "Error", "Failed to execute action")
    } finally {
      setConfirmDialog((prev) => ({ ...prev, isLoading: false }))
    }
  }

  const openEditDialog = (user: User) => {
    setEditDialog({
      isOpen: true,
      user,
      newDays: "30",
      isLoading: false,
    })
  }

  const closeEditDialog = () => {
    setEditDialog({
      isOpen: false,
      user: null,
      newDays: "30",
      isLoading: false,
    })
  }

  const updatePremiumUser = async () => {
    if (!editDialog.user) return

    const days = Number.parseInt(editDialog.newDays)
    if (days <= 0) {
      showNotification("error", "Invalid Input", "Days must be a positive number")
      return
    }

    setEditDialog((prev) => ({ ...prev, isLoading: true }))
    try {
      await userService.addPremiumDaysByUserId(editDialog.user!.id, days)
      showNotification("success", "Premium Updated", `Added ${days} premium days to user ${editDialog.user!.id}`)
      closeEditDialog()
      await loadData()
    } catch (error) {
      console.error("Error updating premium:", error)
      showNotification("error", "Update Error", error.message || "Failed to update premium")
    } finally {
      setEditDialog((prev) => ({ ...prev, isLoading: false }))
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      console.log("Loading admin data...")
      const [usersData, settingsData] = await Promise.all([userService.getAllUsers(), userService.getAppSettings()])

      console.log("Users data loaded:", usersData)
      setUsers(usersData)
      setAppSettings(settingsData)
    } catch (error) {
      console.error("Error loading data:", error)
      showNotification("error", "Load Error", "Failed to load admin data")
    } finally {
      setLoading(false)
    }
  }

  const refreshData = async () => {
    setRefreshing(true)
    try {
      await loadData()
      showNotification("success", "Data Refreshed", "Admin data has been refreshed")
    } catch (error) {
      console.error("Error refreshing data:", error)
      showNotification("error", "Refresh Error", "Failed to refresh data")
    } finally {
      setRefreshing(false)
    }
  }

  const addPremiumToUser = async () => {
    if (!selectedUserId.trim()) {
      showNotification("error", "Invalid Input", "Please enter a valid User ID")
      return
    }

    const days = Number.parseInt(premiumDays)
    if (days <= 0) {
      showNotification("error", "Invalid Input", "Days must be a positive number")
      return
    }

    setManagingPremium(true)
    try {
      await userService.addPremiumDaysByUserId(selectedUserId.trim(), days)
      showNotification("success", "Premium Added", `Added ${days} premium days to user ${selectedUserId}`)
      setSelectedUserId("")
      setPremiumDays("30")
      // Refresh data immediately to show new premium user
      await loadData()
    } catch (error) {
      console.error("Error adding premium:", error)
      showNotification("error", "Premium Error", error.message || "Failed to add premium")
    } finally {
      setManagingPremium(false)
    }
  }

  const removePremiumFromUser = async (userId: string) => {
    showConfirmDialog(
      "Remove Premium",
      `Are you sure you want to remove premium access from user ${userId}?`,
      "warning",
      async () => {
        try {
          await userService.removePremiumFromUser(userId)
          showNotification("success", "Premium Removed", "Premium access removed successfully")
          await loadData()
        } catch (error) {
          console.error("Error removing premium:", error)
          showNotification("error", "Remove Error", "Failed to remove premium access")
        }
      },
    )
  }

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text)
      showNotification("success", "Copied", `${label} copied to clipboard`)
    } catch (error) {
      console.error("Error copying to clipboard:", error)
      showNotification("error", "Copy Error", "Failed to copy to clipboard")
    }
  }

  const updateAppSettings = async (newSettings: Partial<AppSettings>) => {
    try {
      await userService.updateAppSettings(newSettings)
      setAppSettings((prev) => ({ ...prev, ...newSettings }))
      showNotification("success", "Settings Updated", "Application settings updated successfully")
    } catch (error) {
      console.error("Error updating app settings:", error)
      showNotification("error", "Update Error", "Failed to update application settings")
    }
  }

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString()
  }

  const formatRemainingTime = (timestamp: number) => {
    const remaining = timestamp - Date.now()
    if (remaining <= 0) return "Expired"

    const days = Math.floor(remaining / (24 * 60 * 60 * 1000))
    const hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000))

    if (days > 0) return `${days}d ${hours}h`
    if (hours > 0) return `${hours}h`
    return "< 1h"
  }

  const getStatusBadge = (isPremium: boolean, premiumExpiry: number | null) => {
    const isActive = isPremium && premiumExpiry && premiumExpiry > Date.now()
    return isActive ? (
      <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
        <CheckCircle className="h-3 w-3 mr-1" />
        Premium Active
      </Badge>
    ) : (
      <Badge className="bg-gray-500/20 text-gray-300 border-gray-500/30">
        <XCircle className="h-3 w-3 mr-1" />
        Regular User
      </Badge>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Loading admin panel...</p>
        </div>
      </div>
    )
  }

  // Filter premium users - those with isPremium true AND valid expiry
  const premiumUsers = users.filter((u) => {
    const isValidPremium = u.isPremium && u.premiumExpiry && u.premiumExpiry > Date.now()
    console.log(`User ${u.id}: isPremium=${u.isPremium}, premiumExpiry=${u.premiumExpiry}, isValid=${isValidPremium}`)
    return isValidPremium
  })

  console.log("All users:", users)
  console.log("Premium users:", premiumUsers)

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 sm:p-6">
      <Notification
        type={notification.type}
        title={notification.title}
        message={notification.message}
        isVisible={notification.isVisible}
        onClose={hideNotification}
      />

      <ConfirmationDialog
        isOpen={confirmDialog.isOpen}
        onClose={closeConfirmDialog}
        onConfirm={executeConfirmAction}
        title={confirmDialog.title}
        message={confirmDialog.message}
        type={confirmDialog.type}
        isLoading={confirmDialog.isLoading}
      />

      {/* Edit Premium Dialog */}
      <Dialog open={editDialog.isOpen} onOpenChange={closeEditDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5" />
              Edit Premium User
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">User ID</Label>
              <Input
                value={editDialog.user?.id || ""}
                disabled
                className="bg-gray-700 border-gray-600 text-gray-400 font-mono"
              />
            </div>
            <div>
              <Label className="text-gray-300">Current Expiry</Label>
              <Input
                value={editDialog.user?.premiumExpiry ? formatDate(editDialog.user.premiumExpiry) : "Not set"}
                disabled
                className="bg-gray-700 border-gray-600 text-gray-400"
              />
            </div>
            <div>
              <Label className="text-gray-300">Add Premium Days</Label>
              <Input
                type="number"
                value={editDialog.newDays}
                onChange={(e) => setEditDialog((prev) => ({ ...prev, newDays: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                min="1"
                placeholder="Enter days to add"
              />
            </div>
            <div className="flex gap-3 pt-4">
              <Button
                onClick={updatePremiumUser}
                disabled={editDialog.isLoading}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {editDialog.isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Updating...
                  </div>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Update Premium
                  </>
                )}
              </Button>
              <Button
                onClick={closeEditDialog}
                variant="outline"
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <div className="max-w-7xl mx-auto px-2 sm:px-0">
        <div className="mb-6 sm:mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">Admin Panel</h1>
            <p className="text-gray-400 text-sm sm:text-base">Manage users, premium access, and application settings</p>
          </div>
          <Button
            onClick={refreshData}
            disabled={refreshing}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
          >
            {refreshing ? (
              <div className="w-4 h-4 border-2 border-gray-400/30 border-t-gray-400 rounded-full animate-spin"></div>
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 mb-6 sm:mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-3 sm:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-xs sm:text-sm">Total Users</p>
                  <p className="text-lg sm:text-2xl font-bold text-white">{users.length}</p>
                </div>
                <Users className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-3 sm:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-xs sm:text-sm">Premium Users</p>
                  <p className="text-lg sm:text-2xl font-bold text-white">{premiumUsers.length}</p>
                </div>
                <Shield className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-3 sm:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-xs sm:text-sm">Regular Users</p>
                  <p className="text-lg sm:text-2xl font-bold text-white">{users.length - premiumUsers.length}</p>
                </div>
                <Activity className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700 grid grid-cols-2 sm:grid-cols-3 h-auto">
            <TabsTrigger value="users" className="data-[state=active]:bg-gray-700 text-xs sm:text-sm p-2 sm:p-3">
              <Users className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Users</span>
              <span className="sm:hidden">Users</span>
            </TabsTrigger>
            <TabsTrigger value="premium" className="data-[state=active]:bg-gray-700 text-xs sm:text-sm p-2 sm:p-3">
              <Star className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Premium</span>
              <span className="sm:hidden">Premium</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-gray-700 text-xs sm:text-sm p-2 sm:p-3">
              <Settings className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Settings</span>
              <span className="sm:hidden">Settings</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  User Management ({users.length} total)
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 sm:p-6">
                <div className="space-y-4">
                  {users.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No users found</p>
                      <p className="text-sm mt-2">Users will appear here when they use the app</p>
                    </div>
                  ) : (
                    users.map((user) => (
                      <div
                        key={user.id}
                        className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 sm:p-4 bg-gray-700/50 rounded-lg border border-gray-600/50 space-y-2 sm:space-y-0"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-xs sm:text-sm text-white">{user.id}</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyToClipboard(user.id, "User ID")}
                              className="h-6 w-6 p-0 text-gray-400 hover:text-white"
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-gray-400">
                            <Calendar className="h-3 w-3" />
                            Created: {formatDate(user.createdAt)}
                          </div>
                          {user.isPremium && user.premiumExpiry && (
                            <div className="flex items-center gap-2 text-xs text-green-400">
                              <Shield className="h-3 w-3" />
                              Premium Expires: {formatRemainingTime(user.premiumExpiry)}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(user.isPremium, user.premiumExpiry)}
                          {user.isPremium && user.premiumExpiry && user.premiumExpiry > Date.now() && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => removePremiumFromUser(user.id)}
                              className="border-red-600 text-red-400 hover:bg-red-500/10"
                            >
                              <Trash2 className="h-3 w-3 mr-1" />
                              Remove Premium
                            </Button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="premium" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  Manage Premium Access
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 sm:p-6">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                  <div>
                    <Label htmlFor="user-id">User ID</Label>
                    <Input
                      id="user-id"
                      type="text"
                      value={selectedUserId}
                      onChange={(e) => setSelectedUserId(e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white font-mono"
                      placeholder="user_xxxxxxxxx_xxxxxxxxx"
                    />
                  </div>
                  <div>
                    <Label htmlFor="premium-days">Premium Days (Validity)</Label>
                    <Input
                      id="premium-days"
                      type="number"
                      value={premiumDays}
                      onChange={(e) => setPremiumDays(e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white"
                      min="1"
                      placeholder="30"
                    />
                  </div>
                  <div className="flex items-end">
                    <Button
                      onClick={addPremiumToUser}
                      disabled={managingPremium}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      {managingPremium ? (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          Adding...
                        </div>
                      ) : (
                        <>
                          <Plus className="h-4 w-4 mr-2" />
                          Add Premium
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  Premium Users ({premiumUsers.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 sm:p-6">
                <div className="space-y-4">
                  {premiumUsers.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No premium users found</p>
                      <p className="text-sm mt-2">Users with active premium subscriptions will appear here</p>
                    </div>
                  ) : (
                    premiumUsers.map((user) => (
                      <div
                        key={user.id}
                        className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 sm:p-4 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-lg border border-green-500/30 space-y-2 sm:space-y-0"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-xs sm:text-sm text-white">{user.id}</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyToClipboard(user.id, "User ID")}
                              className="h-6 w-6 p-0 text-gray-400 hover:text-white"
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                            <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                              <ShieldCheck className="h-3 w-3 mr-1" />
                              Premium
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-gray-400">
                            <Calendar className="h-3 w-3" />
                            Created: {formatDate(user.createdAt)}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-green-400">
                            <Shield className="h-3 w-3" />
                            Expires: {formatRemainingTime(user.premiumExpiry || 0)}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openEditDialog(user)}
                            className="border-blue-600 text-blue-400 hover:bg-blue-500/10"
                          >
                            <Edit className="h-3 w-3 mr-1" />
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => removePremiumFromUser(user.id)}
                            className="border-red-600 text-red-400 hover:bg-red-500/10"
                          >
                            <Trash2 className="h-3 w-3 mr-1" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Application Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 sm:p-6 space-y-6">
                <div className="flex items-center justify-between p-3 sm:p-4 bg-gray-700/50 rounded-lg border border-gray-600/50">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Wrench className="h-4 w-4 text-orange-400" />
                      <span className="font-medium text-white">Maintenance Mode</span>
                    </div>
                    <p className="text-sm text-gray-400">
                      When enabled, users will see a maintenance message and cannot access the app
                    </p>
                  </div>
                  <Switch
                    checked={appSettings.maintenanceMode}
                    onCheckedChange={(checked) => updateAppSettings({ maintenanceMode: checked })}
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Type className="h-4 w-4 text-blue-400" />
                    <Label htmlFor="app-name" className="text-white font-medium">
                      Application Name
                    </Label>
                  </div>
                  <Input
                    id="app-name"
                    value={appSettings.appName}
                    onChange={(e) => setAppSettings((prev) => ({ ...prev, appName: e.target.value }))}
                    onBlur={(e) => updateAppSettings({ appName: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Enter application name"
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="h-4 w-4 text-green-400" />
                    <Label htmlFor="logo-url" className="text-white font-medium">
                      Logo URL
                    </Label>
                  </div>
                  <Input
                    id="logo-url"
                    value={appSettings.logoUrl}
                    onChange={(e) => setAppSettings((prev) => ({ ...prev, logoUrl: e.target.value }))}
                    onBlur={(e) => updateAppSettings({ logoUrl: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Enter logo image URL"
                  />
                  {appSettings.logoUrl && (
                    <div className="mt-2">
                      <p className="text-sm text-gray-400 mb-2">Logo Preview:</p>
                      <img
                        src={appSettings.logoUrl || "/placeholder.svg"}
                        alt="Logo Preview"
                        className="w-16 h-16 rounded-lg border border-gray-600 object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = "none"
                        }}
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
